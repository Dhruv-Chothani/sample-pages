
"use client";
import React, { useState, useEffect } from "react";

const local_marketing_chennai = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(to bottom, #eff6ff, #ffffff, #ede9fe)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "20px",
    }}>
      <div style={{
        maxWidth: "700px",
        textAlign: "center",
        transition: "all 0.7s",
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateY(0)" : "translateY(20px)"
      }}>
        <span style={{
          display: "inline-block",
          marginBottom: "20px",
          padding: "5px 15px",
          fontSize: "14px",
          fontWeight: "bold",
          borderRadius: "20px",
          backgroundColor: "#bfdbfe",
          color: "#1d4ed8",
        }}>
          Local Marketing in Chennai
        </span>

        <h1 style={{
          fontSize: "34px",
          fontWeight: "bold",
          color: "#111827",
          marginBottom: "20px",
        }}>
          Grow Your Business with the Best Local Marketing in Chennai
        </h1>

        <p style={{
          fontSize: "18px",
          color: "#374151",
          marginBottom: "30px",
        }}>
          We help you dominate Google local search and boost your customer base in Chennai.
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: "10px", alignItems: "center" }}>
          <a href="/contact-us/" style={{
            display: "inline-block",
            padding: "12px 30px",
            backgroundColor: "#2563eb",
            color: "#ffffff",
            borderRadius: "30px",
            textDecoration: "none",
            fontWeight: "bold",
            transition: "background 0.3s",
          }}>
            Get Free Audit
          </a>
          <a href="/contact-us/" style={{
            display: "inline-block",
            padding: "12px 30px",
            backgroundColor: "#22c55e",
            color: "#ffffff",
            borderRadius: "30px",
            textDecoration: "none",
            fontWeight: "bold",
            transition: "background 0.3s",
          }}>
            Contact Experts
          </a>
        </div>
      </div>
    </div>
  );
};

export default local_marketing_chennai;
