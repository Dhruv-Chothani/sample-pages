import React, { useState } from 'react';
import axios from 'axios';

const CsvUploadForm = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setMessage('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      alert('Please select a CSV file first.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      setIsUploading(true);
      const res = await axios.post('http://localhost:3000/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setMessage(`✅ Successfully generated ${res.data.total} pages.`);
    } catch (err) {
      console.error(err);
      setMessage('❌ Error uploading file. Please check your server.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div style={{ padding: '40px', maxWidth: '600px', margin: 'auto', textAlign: 'center' }}>
      <h2>Upload CSV File</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="file"
          accept=".csv"
          onChange={handleFileChange}
        />
        <br /><br />
        <button type="submit" disabled={isUploading}>
          {isUploading ? 'Uploading...' : 'Upload and Generate Pages'}
        </button>
        <br /><br />
        
      </form>
      {message && <p style={{ marginTop: '20px' }}>{message}</p>}
      <button > 
          <a href="/">Go Home</a>
        </button>
    </div>
  );
};

export default CsvUploadForm;
