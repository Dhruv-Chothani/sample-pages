import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import CsvUploadForm from './component/CsvUploadForm'; // Your CSV Upload Form component

// Automatically import all page components
const pages = import.meta.glob('./pages/*.jsx', { eager: true });

// Prepare dynamic routes
const routes = Object.keys(pages).map((path) => {
  const slug = path
    .replace('./pages/', '')
    .replace('.jsx', '');
  const PageComponent = pages[path].default;
  const name = slug.replace(/-/g, ' ');
  return { path: `/${slug}`, Component: PageComponent, name };
});

// Home page listing all links
function HomePage() {
  return (
    <div style={{ padding: '30px' }}>
      <h1>All Generated Pages</h1>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {routes.map(({ path, name }, index) => (
          <li key={index} style={{ marginBottom: '10px' }}>
            <Link to={path} style={{ textDecoration: 'none', color: 'blue' }}>
              {name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

function App() {
  return (
    <Router>
      <div style={{ padding: '20px' }}>
        <h1>CSV Upload & Page Generator</h1>
        <CsvUploadForm />
        <hr />
        <Routes>
          <Route path="/" element={<HomePage />} />
          {/* Dynamically render the pages */}
          {routes.map(({ path, Component }, index) => (
            <Route key={index} path={path} element={<Component />} />
          ))}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
